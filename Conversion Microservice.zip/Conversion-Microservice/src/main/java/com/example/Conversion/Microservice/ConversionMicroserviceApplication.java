package com.example.Conversion.Microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConversionMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConversionMicroserviceApplication.class, args);
	}

}
